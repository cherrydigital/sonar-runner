Sonar Runner
=========================

This is the Sonar Runner plugin

Project homepage:
http://docs.codehaus.org/display/SONAR/Analyzing+with+Sonar+Runner

Issue tracking:
http://jira.codehaus.org/browse/SONARPLUGINS/component/14640

CI builds:
https://sonarplugins.ci.cloudbees.com/job/sonar-runner/
